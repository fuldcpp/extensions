# airdcpp-tiny-fileserver

A tiny local-only static file server for .tgz extension tarballs.

AirDC++'s own "Install extensions from URL..." feature only ever accepts
`http://` or `https://` URLs -- never a local file or network path. That
normally means hosting a tarball somewhere real (e.g. a GitHub repo)
before you can use it. This extension serves a folder of `.tgz` files
straight from your own machine over plain HTTP, so you can point the URL
installer at `http://127.0.0.1:<port>/...` instead.

## How it works

- Always binds to `127.0.0.1` -- this can't be turned off. AirDC++'s own
  "Network adapter for all connections" setting (Settings > Connectivity)
  is also detected automatically and, if it's pinned to a specific
  adapter, that address is listened on too (see "Reaching the server from
  more than one address" below) -- but 127.0.0.1 itself is always active
  regardless.
- The configured folder is scanned **recursively** for `.tgz` files. This
  matches the output layout `build-all-extensions.ps1` already produces
  (`<OutputRoot>\<name>\<name>-<version>.tgz`, one subfolder per
  extension) -- point this at that same `OutputRoot` and every tarball in
  it is servable immediately, no extra setup.
- Visiting `http://127.0.0.1:<port>/` in a browser shows a simple index
  page listing every `.tgz` file found, with size and modified date, each
  linked directly -- copy that link straight into AirDC++'s "Install
  extensions from URL..." dialog.
- The folder is re-scanned on every request, not cached, so a freshly
  rebuilt tarball shows up immediately without restarting anything.
- Only files ending in `.tgz` are ever served, and any `../`-style escape
  attempt outside the configured folder is blocked.

## Settings

- **Folder to serve .tgz files from** -- scanned recursively. Leave empty
  and the server simply doesn't start (a message is logged explaining
  why).
- **Port to listen on** (setting key `listen_port`, renamed from `port`
  in 0.0.8-beta) -- leave empty for the default `8912`. Only matters for
  the localhost binding above; never exposed to the network regardless of
  this value. Anything empty, non-numeric, or outside 1024-65535 falls
  back to the default (`8912`) rather than refusing to start. See "Notes
  (0.0.7-beta)" and "Notes (0.0.8-beta)" below for why this is a plain
  text field rather than a number field, and why it starts empty.
- **Automatically install or update extensions when a new or changed
  .tgz appears in this folder** -- off by default. When turned on, any
  new or rebuilt `.tgz` in the configured folder (including a newer build
  of this extension itself) is installed or updated automatically, with
  no need to manually paste its link into "Install extensions from
  URL...". This restarts the affected extension with no confirmation
  prompt, exactly as pasting the link yourself would.
- **Check for new/changed .tgz files every (seconds)** -- default `15`
  (minimum `5`, maximum `300`). Only relevant while automatic
  install/update is turned on. Lower values pick up a new or rebuilt
  tarball sooner, at the cost of scanning the folder more often.
- **Also listen on these addresses (optional, comma-separated)** -- leave
  empty in the normal case; see "Reaching the server from more than one
  address" below for when and why you'd fill this in.

All five settings take effect immediately when saved -- no restart of the
extension or of AirDC++ needed. Changing the folder, port, or addresses
stops the current server(s) and starts new one(s) with the updated values
right away; toggling automatic install on also runs an immediate check
rather than waiting for the next scheduled one.

## Reaching the server from more than one address

By default the server is reachable only as `http://127.0.0.1:<port>/`,
from this same machine. Two things can add more addresses on top of that,
automatically or manually:

- **Automatic**: AirDC++ has its own "Network adapter for all
  connections" setting (Settings > Connectivity). Normally it's "Any
  (0.0.0.0)", which lets AirDC++'s own outgoing connections reach
  `127.0.0.1` just fine. If it's instead pinned to one specific network
  adapter, AirDC++'s own outgoing connections can no longer reach
  `127.0.0.1` at all -- a socket bound to one specific adapter has no
  route to the separate loopback adapter -- which breaks both "Install
  extensions from URL..." and automatic install/update with a connection
  timeout or "connection closed" error. This extension checks that
  setting via the API (at startup, and every 30 seconds after) and, when
  it's pinned to a specific address, automatically also listens there --
  no configuration needed. A message is logged the moment this is
  detected (and again if it's ever unpinned back to "Any").
- **Manual**: the "Also listen on these addresses" setting, for anything
  beyond the automatic case above -- e.g. a different address a
  particular setup needs. Comma-separated, any address is accepted as
  typed with no validation against this machine's actual adapters.

Either way, adding an address beyond `127.0.0.1` makes the server
reachable from other devices on that network too. The risk is limited --
it only ever serves `.tgz` files -- but it's no longer strictly
localhost-only once another address is added. `127.0.0.1` itself always
keeps working regardless of any address added on top of it, and one
address failing to bind (e.g. a typo, or a LAN address not currently
assigned to this machine) never prevents the others from working -- each
failure is logged individually.

When more than one address is active, auto-install's own self-referencing
download URL prefers the automatically detected AirDC++ address (falling
back to a manually configured one, then to `127.0.0.1`), since that's the
address AirDC++'s own outgoing connection actually needs to use.

## Chat command

- `/fileserver` -- reports whether the server is running, and if so, the
  URL and how many `.tgz` files are currently found.

## Automatic install/update

This is off by default -- see "Settings" above to turn it on.

When on, the configured folder is checked on the interval set above (and
immediately whenever the folder, port, or this setting itself is saved).
Any `.tgz` that's new, or whose size or modified time has changed since
last seen, is queued for install/update through the exact same API call
AirDC++'s own "Install extensions from URL..." dialog uses -- no manual
link-pasting needed. This includes a newer build of this extension
itself: dropping a rebuilt `airdcpp-tiny-fileserver-<version>.tgz` into
the folder updates the running extension in place, the same way it would
update any other extension.

Every extension AirDC++ launches is automatically granted an admin-level
API session, so this call needs no extra permission configuration.

What gets logged to the system log:

- A file being queued: `Auto-install: queued "<file>" for install/update
  (new or changed file detected).`
- A successful install/update, once AirDC++ confirms it:
  `Auto-install: "<file>" installed/updated successfully.`
- A failed install/update: `Auto-install: "<file>" failed to
  install/update: <reason>.`

Which files have already been handled is remembered (by size and
modified time) in a small state file in this extension's own config
folder, so a restart of the extension or of AirDC++ doesn't re-trigger
every existing tarball all over again -- only genuinely new or changed
files are queued.

If the configured folder ever contains more than one build of the *same*
extension at once (e.g. an older `.tgz` that was never cleaned up sitting
next to a freshly rebuilt one), only the highest-version build is ever
installed. Each file's real package name and version are read directly
out of the archive itself, not guessed from its filename, so this works
regardless of naming. This matters because queuing every matching file at
once would let their install jobs race each other inside AirDC++ -- and
whichever one happened to finish last would "win", possibly leaving an
*older* version installed even though a newer one was also queued. Older
duplicates are still recorded as handled (so they're not repeatedly
flagged) but are never themselves installed.

Two checks are also never allowed to run at the same time -- e.g. the
scheduled timer ticking at nearly the same moment as an immediate check
triggered by just saving a settings change. A second check that starts
while one is still running is skipped outright rather than running
alongside it. Without this, two overlapping checks could each decide the
same file is new/changed and queue their own separate install job for
it; those two jobs would then race each other inside AirDC++, and
whichever one finished first (stopping the old process, swapping in the
new files) could tear down the very process still serving the other
job's in-flight download -- surfacing as a failed install with a dropped
connection, even though only one update was actually intended.

## Once it's running

Once this extension is running with the URL logged at startup, you can
also use it to update itself and the other extensions: point AirDC++'s
"Install extensions from URL..." at `http://127.0.0.1:<port>/<file>.tgz`
for any tarball shown on the index page -- including a newer build of
this extension itself, which updates it in place the same way any other
extension update does.

## Notes (0.0.7-beta)

If an address can't be listened on, the system log now explains why in
plain language instead of showing Node's raw error text -- "port already
in use (EADDRINUSE)" rather than "listen EADDRINUSE: address already in
use 192.168.1.50:8912", and similarly for an address that isn't currently
assigned to this machine. The original error code is still included in
parentheses for anyone who wants to search for it.

"Port to listen on" is now a plain text field instead of a number field,
to work around a real AirDC++ Settings-UI bug: clicking the native
up/down spinner on a number-type setting can insert a stray space into
the value (observed turning `8912` into `8 913`), which then fails
AirDC++'s own range validation. Typing the port directly avoids the
spinner entirely. Anything empty, non-numeric, or outside 1024-65535 now
falls back to the default (`8912`) instead of refusing to start.

## Notes (0.0.11-beta)

Auto-install now also recovers automatically when AirDC++ itself fails to
restart an extension right after updating it. This is a real, confirmed
AirDC++ timing issue (verified against its own source): when an extension
is updated while it's still running, AirDC++ stops the old process,
swaps in the new files, and restarts it again immediately, with no delay
at all -- unlike its own crash-recovery path, which deliberately waits a
few seconds first "for the log file handles to get closed". On Windows,
that missing delay can occasionally lose a race against the just-stopped
process still releasing its own output.log file handle, so the restart
fails with "Failed to initialize the extension log ...: Het proces heeft
geen toegang tot het bestand..." (or the English equivalent), even though
the file update itself succeeded. Since auto-install already knows
exactly which extension it just triggered an update for, it now checks a
few seconds afterwards whether that extension is actually running and,
if not, starts it itself through the same API AirDC++'s own Extensies
panel uses -- no more needing to notice and start it by hand. A log
message explains what happened either way.

## Notes (0.0.10-beta)

The 0.0.8-beta fix for the oversized/spinner-y "Port to listen on" field
(switching it to `type: "text"`) turned out to trade one AirDC++ Settings-UI
quirk for another: some AirDC++ versions render a `"text"` field as a large,
multi-line box with its own scrollbar, confirmed by a screenshot. The
setting is now back to `type: "string"` (still starts empty, still the
`listen_port` key from 0.0.8-beta) -- on the AirDC++ versions this was
tested against, that renders as a normal, compact single-line box. As
before, this only affects how the box looks in AirDC++'s own Settings
dialog; the value typed into it is parsed and used the same way regardless.

## Notes (0.0.9-beta)

Shortened the titles and help text of all 5 settings, since the fuller
explanations (still below, in "Notes (0.0.7-beta)" and "Notes
(0.0.8-beta)") were making AirDC++'s Settings dialog very large. No
functional change -- only the wording shown in AirDC++'s Settings tab.

## Notes (0.0.8-beta)

Some AirDC++ versions were still rendering "Port to listen on" as a
narrow, spinner-equipped box even after the 0.0.7-beta change above --
apparently AirDC++'s Settings dialog can render a field that way based on
its current value looking like a plain number, regardless of the JSON
"type" declared for it. As a best-effort fix, the setting was renamed
from `port` to `listen_port` (so AirDC++ treats it as a brand new setting
rather than possibly reusing a stale definition it learned for the old
key), switched from `type: "string"` to `type: "text"`, and now starts
empty instead of pre-filled with `8912`. If your AirDC++ still shows a
narrow box or spinner arrows after this, that's happening entirely inside
AirDC++'s own (closed to us) Settings dialog code -- the value you type
is still parsed and used correctly regardless of how the box looks.

Anyone upgrading from an older version who had already set a custom port
will need to re-enter it once, since the old `port` value doesn't carry
over to the new `listen_port` key -- leaving it empty still means 8912,
same as before.

## Building from source

```
npm install
npm run build
```

Produces `dist/main.js`. Copy this project's folder (with `dist/main.js`
and `package.json`) into your AirDC++ extensions folder, or zip it up the
way the packaged release is structured.
