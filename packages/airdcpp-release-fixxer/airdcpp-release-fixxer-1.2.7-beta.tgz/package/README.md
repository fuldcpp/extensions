# airdcpp-release-fixxer

Fork of the official AirDC++ release validator. Scans downloaded and
shared release directories for missing/extra files (CRC/SFV/NFO) and
automatically redownloads what's broken or missing.

## Detects

Via scan or automatically on new/completed downloads:

- CRC errors (file does not match the `.sfv`)
- Missing files (`file_missing`)
- Missing SFV (`sfv_missing`)
- Missing NFO (`nfo_missing`)
- Broken/unreadable SFV -- not a single valid line could be parsed from it
  (`invalid_sfv_file`)
- Folders containing only an nfo/sfv but nothing else (`no_release_files`)
- Incomplete releases where the source only ever offered a Sample and/or
  Proof plus an NFO, with no SFV and no real content at all
  (`incomplete_no_sfv`) -- these otherwise slip through undetected, since
  AirDC++'s download queue considers the bundle finished and there's no
  SFV to compare against. Configurable exemption list for release types
  that legitimately never ship an SFV (dirfix, proofix, etc.) -- see
  Settings below.
- Plus the standard checks from the original validator: extra files,
  duplicate nfo/sfv, etc. -- these are only reported, not fixed
  automatically, since "redownload" isn't a solution for those

## Takes action on (CRC-redownload)

- **CRC error** -- the file is automatically deleted, after which the
  release folder is searched for and downloaded.
- **Broken/unreadable SFV** -- the `.sfv` file itself is deleted first
  (otherwise "file already exists on disk" would block a new download of
  it), after which the release folder is searched for and downloaded.
- **Missing file / SFV / NFO / no_release_files / incomplete_no_sfv** --
  the release folder is searched for and downloaded.

## Chat commands

- `/rvalidator scan` -- scan the entire share.
- `/rvalidator scan <path>` -- scan only that specific folder.
- `/rvalidator help`

## Smart features

- Background redownload searches use the lowest search priority (1), so
  manual searches/downloads from the AirDC++ UI always get sent to the
  hub first.
- One-at-a-time queue -- prevents "Search queue overflow".
- Subs/Sub/SUBPACK folders: still searched, but no warning if nothing is
  found.
- Reports itself in the system log when AirDC++ starts, listing the
  available commands.
- Node.js DEP0169 deprecation warning suppressed; all other warnings
  still print normally.

## Settings

`crc_delete_files`, `crc_redownload` (both on by default),
`incomplete_no_sfv` (on by default -- toggles the check described
above).

- **Release names allowed to have no SFV** (`no_sfv_exempt_patterns`) --
  comma-separated list, `*` matches any run of characters, e.g.
  `*.dirfix.*,*.proofix.*`. Matched against the whole release folder
  name, case-insensitive. A folder matching one of these is never
  flagged by the `incomplete_no_sfv` check, regardless of its content.
  Tip: real release names usually put a hyphen (not a dot) before the
  group tag, so a pattern like `*dirfix*` (no surrounding dots) matches
  more reliably than `*.dirfix.*` unless you've checked the exact naming
  your sources use. Takes effect immediately, no restart needed. Only
  affects the `incomplete_no_sfv` check, not `sfv_missing`.

## Conflict check with the original validator

At every startup, this checks whether `airdcpp-release-validator` (the
extension it was forked from) is also installed and enabled, and if so,
automatically disables its autostart. Running both at once means they'd
react independently to the same downloads/share scans -- doubling up
redownload searches and search-queue pressure.

This is deliberately conservative:

- It only disables autostart, never uninstalls/removes the other
  extension -- fully reversible anytime in Settings > Extensions.
- It never blocks release-fixxer's own startup, even if the check or the
  disable itself fails (most likely a missing `admin` permission) -- a
  warning is logged in that case instead.
- It only affects *autostart*. If the original validator is already
  running in the current AirDC++ session when this check runs, restart
  AirDC++ (or stop it manually) for the disable to fully take effect this
  session.
- It runs on every startup, so if the original validator is ever manually
  re-enabled, it gets disabled again the next time AirDC++ starts.

## Works together with

Works independently from `airdcpp-sample-proof-checker`, which
specifically checks Sample/Proof subfolders. Works together with
`airdcpp-sfv-folder-checker`: that extension writes a JSON report this
extension can read, and it also detects CRC mismatches at the file level
itself.

## Notes (1.2.7-beta)

Shortened the `incomplete_no_sfv` setting's title from a long
one-line description to just "Check for incomplete releases (no SFV)"
-- it was getting cut off in AirDC++'s Settings dialog. The detail
that was in the title (NFO required, automatic redownload only on a
freshly-finished download, manual scans only report) moved into the
setting's help text instead. No behavior change.

## Notes (1.2.6-beta)

Removed two settings that were rarely worth touching, in favor of
just always doing the sensible thing:

- "Log actions to the system log" (`crc_log_events`) -- was on by
  default anyway; the CRC-redownload actions it gated are now always
  logged.
- "Ignore files/directories that are excluded from share"
  (`ignore_excluded`) -- defaulted to on on Windows, off elsewhere.
  Now always off (never ignore), since skipping a check for content
  you deliberately downloaded made little sense as a default.

Neither is a behavior change for most setups -- both settings kept
their default value, just without a way to turn them off anymore.

## Notes (b1.2.5)

Added the `incomplete_no_sfv` check: a release folder with no SFV, no
real content at the top level, and only a Sample and/or Proof (or
Cover/Sub) subfolder alongside its NFO is now treated the same as a
missing-file release and re-searched/redownloaded. Previously this case
was invisible to every existing check -- `sfv_missing` only looks at
top-level files, and `no_release_files` only fires when there are no
subfolders at all. A folder consisting only of disc-style subfolders
(CD1/CD2/DISC1/...) is deliberately never flagged by this check, since
that's a normal structure checked per-subfolder instead. Configure
`no_sfv_exempt_patterns` for release types that legitimately never ship
an SFV.

## Notes

`package.json` is marked `"private": true` (same as the other 3
extensions), which stops AirDC++ from checking npmjs.org for updates to
this extension -- it was never published there, so that check always
failed with a 404. This was the one extension still missing that field,
inherited from being forked from the officially-published original.

## Building from source

```
npm install
npm run build
```

Produces `dist/main.js`. Copy this project's folder (with `dist/main.js`
and `package.json`) into your AirDC++ extensions folder, or zip it up the
way the packaged release is structured.
