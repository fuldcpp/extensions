# airdcpp-release-fixxer

Fork of the official AirDC++ release validator. Scans downloaded and
shared release directories for missing/extra files (CRC/SFV/NFO) and
automatically redownloads what's broken or missing.

## Detects

Via scan or automatically on new/completed downloads:

- CRC errors (file does not match the `.sfv`)
- Missing files (`file_missing`)
- Missing SFV (`sfv_missing`)
- Missing NFO (`nfo_missing`)
- Broken/unreadable SFV -- not a single valid line could be parsed from it
  (`invalid_sfv_file`)
- Folders containing only an nfo/sfv but nothing else (`no_release_files`)
- Incomplete releases where the source only ever offered a Sample and/or
  Proof plus an NFO, with no SFV and no real content at all
  (`incomplete_no_sfv`) -- these otherwise slip through undetected, since
  AirDC++'s download queue considers the bundle finished and there's no
  SFV to compare against. Configurable exemption list for release types
  that legitimately never ship an SFV (dirfix, prooffix, etc.) -- see
  Settings below.
- Plus the standard checks from the original validator: extra files,
  duplicate nfo/sfv, etc. -- these are only reported, not fixed
  automatically, since "redownload" isn't a solution for those

## Takes action on (CRC-redownload)

- **CRC error** -- the file is automatically deleted, after which the
  release folder is searched for and downloaded.
- **Broken/unreadable SFV** -- the `.sfv` file itself is deleted first
  (otherwise "file already exists on disk" would block a new download of
  it), after which the release folder is searched for and downloaded.
- **Missing file / SFV / NFO / no_release_files / incomplete_no_sfv** --
  the release folder is searched for and downloaded.

## Chat commands

- `/rvalidator scan` -- scan the entire share.
- `/rvalidator scan <path>` -- scan only that specific folder.
- `/rvalidator accept <path>` -- accept that folder as final; no check
  will flag it again, and no further automatic redownload for it.
- `/rvalidator unaccept <path>` -- undo `/rvalidator accept` for that
  folder.
- `/rvalidator help`

## Smart features

- Background redownload searches use the lowest search priority (1), so
  manual searches/downloads from the AirDC++ UI always get sent to the
  hub first.
- One-at-a-time queue -- prevents "Search queue overflow".
- Subs/Sub/SUBPACK folders: still searched, but no warning if nothing is
  found.
- Reports itself in the system log when AirDC++ starts, listing the
  available commands.
- Node.js DEP0169 deprecation warning suppressed; all other warnings
  still print normally.

## Settings

`crc_delete_files`, `crc_redownload` (both on by default),
`incomplete_no_sfv` (on by default -- toggles the check described
above).

- **Release names allowed to have no SFV** (`no_sfv_exempt_patterns`) --
  comma-separated list, `*` matches any run of characters, e.g.
  `*.dirfix.*,*.prooffix.*,*.nfofix.*,*.samplefix.*,*.fix.*` (the shipped default). Matched against the whole release folder
  name, case-insensitive. A folder matching one of these is never
  flagged by the `incomplete_no_sfv` check, regardless of its content.
  Tip: real release names usually put a hyphen (not a dot) before the
  group tag, so a pattern like `*dirfix*` (no surrounding dots) matches
  more reliably than `*.dirfix.*` unless you've checked the exact naming
  your sources use. Takes effect immediately, no restart needed. Only
  affects the `incomplete_no_sfv` check, not `sfv_missing`.

## Conflict check with the original validator

At every startup, this checks whether `airdcpp-release-validator` (the
extension it was forked from) is also installed and enabled, and if so,
automatically disables its autostart. Running both at once means they'd
react independently to the same downloads/share scans -- doubling up
redownload searches and search-queue pressure.

This is deliberately conservative:

- It only disables autostart, never uninstalls/removes the other
  extension -- fully reversible anytime in Settings > Extensions.
- It never blocks release-fixxer's own startup, even if the check or the
  disable itself fails (most likely a missing `admin` permission) -- a
  warning is logged in that case instead.
- It only affects *autostart*. If the original validator is already
  running in the current AirDC++ session when this check runs, restart
  AirDC++ (or stop it manually) for the disable to fully take effect this
  session.
- It runs on every startup, so if the original validator is ever manually
  re-enabled, it gets disabled again the next time AirDC++ starts.

## Works together with

Works independently from `airdcpp-sample-proof-checker`, which
specifically checks Sample/Proof subfolders. Works together with
`airdcpp-sfv-folder-checker`: that extension writes a JSON report this
extension can read, and it also detects CRC mismatches at the file level
itself.

## Notes (1.2.20-beta)

The 1.2.19-beta fix (an exact `overrides` pin plus a `tsconfig.json`
`paths` redirect pointing at the real `airdcpp-apisocket` file inside
`node_modules`) turned out not to be enough -- it still failed with the
exact same `TS7016: Could not find a declaration file` error on a real
build elsewhere, which meant that machine's `node_modules` genuinely
never had a usable declaration file for `airdcpp-apisocket` to redirect
to in the first place (regardless of the version-pinning). This release
removes that dependency entirely: a full, unmodified copy of the real
`airdcpp-apisocket` type declarations now lives in this project's own
`src/types/airdcpp-apisocket-vendor/`, and `tsconfig.json`'s `paths`
entry points there instead of into `node_modules`. Type-checking no
longer depends on what `npm install` happens to resolve for this
package on any given machine. Verified two ways: with a normal
`node_modules` install (types resolve fine either way, no conflict),
and with the real `node_modules` declaration files deliberately deleted
to reproduce the reported failure directly (0 errors either way,
`tsc --noEmit`, the real webpack build, and the full 29-test Jest suite
all pass). No functional/runtime change -- this only affects
compile-time type-checking.

## Notes (1.2.19-beta)

Build-robustness fix, no functional change: `airdcpp-apisocket` (a
transitive dependency, pulled in via `airdcpp-extension`) ships a
package.json `exports` map with no `types` condition, so whether
TypeScript can find its type declarations at all depends on subtle,
version-specific fallback behavior -- this built and type-checked fine
in testing here, but failed with `TS7016: Could not find a declaration
file for module 'airdcpp-apisocket'` (and a cascade of ~19 follow-on
implicit-any errors from it) in a real build elsewhere. Fixed two ways:
added an exact `overrides` pin for `airdcpp-apisocket` so the same
known-good version is always installed regardless of what
`airdcpp-extension` itself requests, and added a `tsconfig.json`
`paths` entry that points TypeScript directly at that version's real
declaration file for type-checking purposes only (webpack/ts-loader's
actual runtime module resolution is untouched). Also pinned
`typescript` itself to an exact, current version rather than a
`^5.0.2` range, since TypeScript's "bundler" module resolution mode
(used by this project) was new in 5.0 and has had resolution-fallback
refinements since. Verified with a full clean `node_modules` reinstall,
a standalone `tsc --noEmit` pass, the normal webpack build, and the
Jest suite (still 29/29 passing).

## Notes (1.2.18-beta)

Version bump only, doc cleanup: removed remaining references to the
project's original development language/origin from the docs. No
source code changed; all 29 tests still pass and the built bundle
behaves identically.

## Notes (1.2.17-beta)

Version bump only, to mark a documentation cleanup as its own release:
the top `README.md` note was rewritten in plain English, and a
`.gitignore` merge error from packaging this project for GitHub
(`node_modules/` had accidentally been glued onto the previous line,
`/*.txt`, so it wasn't actually being ignored) was fixed. No source
code changed; all 29 tests still pass and the built bundle behaves
identically.

## Notes (1.2.16-beta)

Fixed a bug where `/rvalidator help` produced no response at all.
AirDC++ delivers `/rvalidator help` as command `rvalidator` with `help`
as an argument, never as a bare command `help` -- but the help text
lived under its own top-level switch case that could only ever match a
literal, undocumented `/help`, so the documented `/rvalidator help`
fell through every branch and silently did nothing. Moved the help
response inside the `rvalidator` case itself, alongside
scan/accept/unaccept, so it now also fires on a bare `/rvalidator` with
no arguments at all. No other functional change.

## Notes (1.2.15-beta)

Added a way to manually accept a release folder as final and,
separately, a native-backed way to force a rejected download straight
into the share. Two independent additions:

- `/rvalidator accept <path>` and `/rvalidator unaccept <path>` -- put a
  real disk path on (or take it off) a small persisted exemption list.
  Once accepted, every check -- manual scan, automatic on completed
  download, and automatic on new share directory -- skips that exact
  folder entirely (subfolders are not exempted, so a multi-disc release
  with one bad disc is still checked disc by disc). Useful for something
  like an NFO-less release where an NFOFIX is expected to show up later:
  accept the folder so it stops being flagged while that's pending. The
  list survives an extension or AirDC++ restart (stored in this
  extension's own config folder) and is not exposed as a regular
  setting, since a free-text list of full disk paths, potentially many
  and always machine-written, doesn't fit the Settings dialog well.
- Right-click "Accept and force into share (bypass validation)" on a
  bundle in the Download Queue screen -- only offered when that bundle
  is actually stuck in a failed-validation state. Adds it to the
  accepted-paths list above, then pushes it into the share via AirDC++'s
  own native `POST queue/bundles/:id/share` call with `skip_validation`,
  the same mechanism AirDC++'s own Queue screen itself offers for a
  bundle stuck there -- no custom sharing logic of this extension's own.
  Accepting first (rather than just calling that API directly) matters
  because AirDC++ runs its "Scan new share directories" hook right after
  a bundle is shared, regardless of `skip_validation` -- without the
  accept, this extension's own hook could immediately re-flag the same
  folder a moment later.

No changes to any existing check, setting, or the automatic
CRC-redownload behavior.

## Notes (1.2.13-beta)

Fixed a typo in the "Release names allowed to have no SFV" setting: the example was `*.proofix.*`, but the real release tag is `PROOFFIX` (double F). Also gave `no_sfv_exempt_patterns` a sensible non-empty default instead of shipping empty: `*.dirfix.*,*.prooffix.*,*.nfofix.*,*.samplefix.*,*.fix.*`. These are all release types that legitimately ship with only an NFO and a Sample/Proof subfolder (no SFV, no real content) by design, not because the download is broken -- e.g. a SAMPLEFIX release with just an NFO and a Sample folder was being wrongly flagged as `incomplete_no_sfv` before this. Existing installs keep whatever value they already have in this setting; the new default only applies on a fresh install.

## Notes (1.2.12-beta)

Added a "files": ["dist"] field to package.json. Without it, `npm pack`
(or an eventual `npm publish`) would include everything not explicitly
excluded by .npmignore -- CHANGELOG.md, jest.config.js, tsconfig.json,
webpack.config.cjs -- none of which the extension needs at runtime,
since `dist/main.js` is a self-contained webpack bundle with all
dependencies already inlined. Packaging is smaller and cleaner now; no
functional change.

## Notes (1.2.11-beta)

Shortened the "Check for incomplete releases (no SFV)" setting's help
text at the user's request -- from a longer explanation covering the
NFO requirement, the Sample-folder-without-NFO exception, and the
conditional re-download behavior, down to one plain sentence: "Tries to
redownload a folder that has an NFO and only Sample/Proof/Subs/Covers
subfolders, no SFV, and no real content files." Note that the actual
redownload still only happens if "Automatically re-search and
redownload the release folder" is also on -- this check alone detects
and flags, same as before; only the help text changed. No other
functional change.

## Notes (1.2.10-beta)

Reverted the 1.2.9-beta rename: back to `airdcpp-release-fixxer`. Turns
out the official "name must start with airdcpp-" requirement is real
after all, just narrower than a quick test had suggested -- a minimal
test extension with no settings (`dce-hello-fixxer`) loaded, ran, and
handled chat commands fine under a non-`airdcpp-`-prefixed name, which
looked like proof the whole requirement was obsolete. But every real
extension in this family uses settings, and AirDC++ rejects the
settings-registration API call (`POST extensions/<name>/settings/
definitions`) for a non-`airdcpp-`-prefixed name -- confirmed with an
isolated one-line diff (only `name`/`version` changed, nothing else)
that reproduced a clean crash: a 400 on that endpoint, silently
swallowed by the settings library, followed by a hard crash the moment
any setting was read. Confirmed consistent even after a full AirDC++
restart, so not a one-time registration race either. Back to
`airdcpp-` for good. No functional change otherwise.

## Notes (1.2.9-beta)

Renamed the package from `airdcpp-release-fixxer` to `airdcpp-release-fixxer`.
AirDC++'s official extension spec says a package name "must start with
airdcpp-", but that turned out to only apply to extensions published
through npm's own registry and picked up via AirDC++'s in-app update
checker -- a locally-installed or FulDC++-catalogue extension with a
non-`airdcpp-`-prefixed name loads and runs identically (confirmed with
a small purpose-built test extension, installed manually and via
`dce-tiny-fileserver`'s auto-install, in real AirDC++ 4.30). Since this
whole family is only ever installed that way, `dce-` (Direct Connect
Extension) reads better than a name implying it only works with one
specific client. No functional change otherwise -- everything below the
`dce-` rename still behaves exactly as before.

## Notes (1.2.8-beta)

Added `repository` and `bugs` fields to `package.json`, pointing at this
fork's own GitHub source (placeholder URL -- replace
`YOUR-USERNAME-HERE` with the real account/repo before actually running
`npm publish`) instead of the upstream `airdcpp-release-validator`
project's repo, which is where they incorrectly still pointed (and, as
written, weren't even a valid git URL). Also flipped `private` from
`true` back to `false`, in preparation for an eventual real npm
publish -- see "A note on `private: true`" below for why this
reintroduces a previously-fixed cosmetic issue until that publish
actually happens.

## Notes (1.2.7-beta)

Shortened the `incomplete_no_sfv` setting's title from a long
one-line description to just "Check for incomplete releases (no SFV)"
-- it was getting cut off in AirDC++'s Settings dialog. The detail
that was in the title (NFO required, automatic redownload only on a
freshly-finished download, manual scans only report) moved into the
setting's help text instead. No behavior change.

## Notes (1.2.6-beta)

Removed two settings that were rarely worth touching, in favor of
just always doing the sensible thing:

- "Log actions to the system log" (`crc_log_events`) -- was on by
  default anyway; the CRC-redownload actions it gated are now always
  logged.
- "Ignore files/directories that are excluded from share"
  (`ignore_excluded`) -- defaulted to on on Windows, off elsewhere.
  Now always off (never ignore), since skipping a check for content
  you deliberately downloaded made little sense as a default.

Neither is a behavior change for most setups -- both settings kept
their default value, just without a way to turn them off anymore.

## Notes (b1.2.5)

Added the `incomplete_no_sfv` check: a release folder with no SFV, no
real content at the top level, and only a Sample and/or Proof (or
Cover/Sub) subfolder alongside its NFO is now treated the same as a
missing-file release and re-searched/redownloaded. Previously this case
was invisible to every existing check -- `sfv_missing` only looks at
top-level files, and `no_release_files` only fires when there are no
subfolders at all. A folder consisting only of disc-style subfolders
(CD1/CD2/DISC1/...) is deliberately never flagged by this check, since
that's a normal structure checked per-subfolder instead. Configure
`no_sfv_exempt_patterns` for release types that legitimately never ship
an SFV.

## A note on `private: true`

`package.json` currently has `"private": false` -- flipped back from
`true` in 1.2.8-beta to prepare for an eventual real `npm publish`.
Until that publish actually happens, this brings back a small cosmetic
issue that `private: true` had deliberately fixed: AirDC++ checks
npmjs.org for updates to installed extensions, and since this package
still isn't actually published there, that check will fail with a 404
again (harmless, just a log line). If this extension is being installed
from source/zip rather than through an actual npm publish, setting
`private` back to `true` removes that log line with no other effect.

## Building from source

```
npm install
npm run build
```

Produces `dist/main.js`. Copy this project's folder (with `dist/main.js`
and `package.json`) into your AirDC++ extensions folder, or zip it up the
way the packaged release is structured.
