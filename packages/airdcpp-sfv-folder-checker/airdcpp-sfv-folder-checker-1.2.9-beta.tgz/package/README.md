airdcpp-sfv-folder-checker (1.2.9-beta):

Hub command /sfvcheck <folder> that recursively checks a folder for .sfv
files and compares their CRC32 against the real files on disk. Works
together with airdcpp-release-fixxer.

•	/sfvcheck [folder] [full] — searches a folder (and subfolders) for .sfv files and checks the CRC32 of every listed file against what is actually on disk, using the real path (not the virtual share name).
        [folder] can also be set within the extension itself, in which case /sfvcheck without a path is enough.
        Add "full" (/sfvcheck [folder] full) to ignore the incremental cache and re-hash every file, regardless of modification date.
•	/sfvstop — cancels a running scan. The current file is still finished, after which the scan stops cleanly. Whatever has already been checked up to that point stays in the cache and the report.
•	Native CRC32 (via zlib, Node.js 21+) instead of a JS implementation — tens of times faster. On older Node versions the extension automatically falls back to a JS implementation; which path is active is reported in the system log when the extension starts.
•	Retry on stat/hash errors: automatically retried up to 3 times with a short pause in between before it's reported as a real problem.
•	Processes multiple release folders at once (configurable count, default 8). Files within 1 release folder are always hashed one after another; only different release folders run in parallel.
•	Incremental cache (configurable, on by default): remembers file size + modification date per file after a successful check, so unchanged files are skipped on the next /sfvcheck.
        NOTE: relies on the filesystem's modification date; bitrot that doesn't change it won't be caught. Run /sfvcheck [folder] full occasionally as an extra check.
•	Automatic cache cleanup: entries not seen for a configurable number of days (default 90) are removed after each scan. Set to 0 to disable.
•	After a scan in which files were deleted (CRC mismatch), the built-in AirDC++ "Optimize database" action is triggered once to clean up orphaned hash records. Can be turned off.
•	Progress messages in the system log during a scan (max. once every 5 sec.), indicating whether a file came from the cache.
•	JSON report per scan (in the extension's log folder) with all results, for airdcpp-release-fixxer to read.
•	Optional (on by default): automatically delete files with a CRC mismatch, so they can be redownloaded — applies to every mismatch, including ones that came from the cache.
•	As soon as a file is deleted, the extension searches for and downloads the corresponding release folder itself. Multiple deleted files from the same release folder within 1 scan only trigger 1 search. Searches happen one at a time with a configurable pause in between (default 15 sec.), using the lowest search priority (1) so manual searches/downloads always get sent to the hub first.
•	Right-click "Check SFV/CRC for this folder" on folders in Own filelist. The extension logs to the system log at startup whether the menu item registered successfully, failed, or was skipped — check that log line if the menu item doesn't appear.

Settings:
•	Default folder to scan — real disk path, used when /sfvcheck is typed without a path.
•	Number of release folders to process at once — default 8.
•	Only re-hash changed files — the incremental cache, on by default.
•	Clean up cache entries after (days) not seen — default 90.
•	Automatically delete files with a CRC mismatch — on by default.
•	Automatically redownload deleted (CRC mismatch) files — on by default.
•	Wait time (seconds) between automatic redownload searches — default 15.
•	Clean up the AirDC++ hash database after deleted files — on by default.

## Notes (1.2.9-beta)

`/sfvhelp` (and `/sfvcheck help`) now shows the help text as a clear
list of commands, one per line, instead of one long paragraph -- and
the reply always appears in the same hub/PM window the command was
typed in (it already did; only the text layout changed).

## Notes (1.2.8-beta)

Fixed a bug where `/sfvcheck help` was silently stat()'d as a literal
folder path (`help`), instead of showing usage -- resulted in a
confusing "Folder not found: help" (or, if a scan happened to already
be running, an unrelated "already running" message). The separate
`/sfvhelp` command already worked correctly and is unchanged; this just
also catches the more natural `<command> help` typing pattern (only
when "help" is the entire path argument, checked after the "full"
modifier is stripped -- a real path is still free to contain the
word). Same class of bug found and fixed at the same time in
airdcpp-sample-proof-checker and airdcpp-share-backup.

## Notes (1.2.6-beta)

Reverted the 1.2.5-beta rename: back to airdcpp-sfv-folder-checker (and
the sibling references above back to airdcpp-release-fixxer /
airdcpp-sample-proof-checker). Turns out the official "name must start
with airdcpp-" requirement is real after all, just narrower than a
quick test had suggested -- a minimal test extension with no settings
(dce-hello-fixxer) loaded, ran, and handled chat commands fine under a
non-airdcpp--prefixed name, which looked like proof the whole
requirement was obsolete. But every real extension in this family uses
settings, and AirDC++ rejects the settings-registration API call (POST
extensions/<name>/settings/definitions) for a non-airdcpp--prefixed
name -- confirmed with an isolated one-line diff (only name/version
changed, nothing else) that reproduced a clean crash: a 400 on that
endpoint, silently swallowed by the settings library, followed by a
hard crash the moment any setting was read. Confirmed consistent even
after a full AirDC++ restart, so not a one-time registration race
either. Back to airdcpp- for good. No functional change otherwise.

## Notes (1.2.5-beta)

Renamed the package from `airdcpp-sfv-folder-checker` to
`airdcpp-sfv-folder-checker` (and its sibling `airdcpp-release-fixxer` /
`airdcpp-sample-proof-checker` references above to `airdcpp-release-fixxer`
/ `airdcpp-sample-proof-checker`). AirDC++'s official extension spec says a
package name "must start with airdcpp-", but that turned out to only
apply to extensions published through npm's own registry and picked up
via AirDC++'s in-app update checker -- a locally-installed or
FulDC++-catalogue extension with a non-`airdcpp-`-prefixed name loads
and runs identically (confirmed with a small purpose-built test
extension, installed manually and via `dce-tiny-fileserver`'s
auto-install, in real AirDC++ 4.30). Since this whole family is only
ever installed that way, `dce-` (Direct Connect Extension) reads better
than a name implying it only works with one specific client. No
functional change otherwise.

## Notes (1.2.4-beta)

Added `repository` and `bugs` fields to `package.json` (placeholder
GitHub URL -- replace `YOUR-USERNAME-HERE` with the real account/repo
before actually running `npm publish`), and flipped `private` from
`true` back to `false` in preparation for an eventual real npm publish.
Until that publish actually happens, this brings back the npmjs.org
update-check 404 that `private: true` had deliberately silenced --
harmless, just a log line, and easy to re-suppress by setting `private`
back to `true` for anyone installing from source/zip rather than a real
npm publish. Also note: this doc's version header above ("b1.2.1") was
stale before this update -- the actual shipped version has been
1.2.3-beta/1.2.4-beta for a while; only the number in this file's first
line hadn't been kept in sync.
